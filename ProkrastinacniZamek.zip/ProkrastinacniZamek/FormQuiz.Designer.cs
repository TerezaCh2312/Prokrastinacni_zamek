namespace ProkrastinacniZamek
{
    partial class FormQuiz
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.Label lblOtazka;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.Button btnDalsi;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components  = new System.ComponentModel.Container();
            this.lblProgress = new System.Windows.Forms.Label();
            this.lblOtazka   = new System.Windows.Forms.Label();
            this.btnA        = new System.Windows.Forms.Button();
            this.btnB        = new System.Windows.Forms.Button();
            this.btnC        = new System.Windows.Forms.Button();
            this.btnD        = new System.Windows.Forms.Button();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.btnDalsi    = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblProgress
            this.lblProgress.AutoSize  = false;
            this.lblProgress.BackColor = System.Drawing.Color.Transparent;
            this.lblProgress.Font      = new System.Drawing.Font("Consolas", 10F);
            this.lblProgress.ForeColor = System.Drawing.Color.FromArgb(180, 180, 180);
            this.lblProgress.Location  = new System.Drawing.Point(30, 20);
            this.lblProgress.Name      = "lblProgress";
            this.lblProgress.Size      = new System.Drawing.Size(840, 26);
            this.lblProgress.TabIndex  = 0;
            this.lblProgress.Text      = "Otázka 1 / 5   |   ✅ Správně: 0";
            this.lblProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // lblOtazka
            this.lblOtazka.AutoSize  = false;
            this.lblOtazka.BackColor = System.Drawing.Color.Transparent;
            this.lblOtazka.Font      = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.lblOtazka.ForeColor = System.Drawing.Color.FromArgb(255, 220, 100);
            this.lblOtazka.Location  = new System.Drawing.Point(30, 55);
            this.lblOtazka.Name      = "lblOtazka";
            this.lblOtazka.Size      = new System.Drawing.Size(840, 70);
            this.lblOtazka.TabIndex  = 1;
            this.lblOtazka.Text      = "Otázka se načte...";

            // btnA
            this.btnA.BackColor                  = System.Drawing.Color.FromArgb(40, 40, 60);
            this.btnA.Cursor                     = System.Windows.Forms.Cursors.Hand;
            this.btnA.FlatStyle                  = System.Windows.Forms.FlatStyle.Flat;
            this.btnA.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 80, 120);
            this.btnA.FlatAppearance.BorderSize  = 1;
            this.btnA.Font                       = new System.Drawing.Font("Consolas", 11F);
            this.btnA.ForeColor                  = System.Drawing.Color.White;
            this.btnA.Location                   = new System.Drawing.Point(30, 140);
            this.btnA.Name                       = "btnA";
            this.btnA.Size                       = new System.Drawing.Size(840, 50);
            this.btnA.TabIndex                   = 2;
            this.btnA.Text                       = "  A)  ...";
            this.btnA.TextAlign                  = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA.UseVisualStyleBackColor    = false;
            this.btnA.Click                     += new System.EventHandler(this.btnA_Click);

            // btnB
            this.btnB.BackColor                  = System.Drawing.Color.FromArgb(40, 40, 60);
            this.btnB.Cursor                     = System.Windows.Forms.Cursors.Hand;
            this.btnB.FlatStyle                  = System.Windows.Forms.FlatStyle.Flat;
            this.btnB.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 80, 120);
            this.btnB.FlatAppearance.BorderSize  = 1;
            this.btnB.Font                       = new System.Drawing.Font("Consolas", 11F);
            this.btnB.ForeColor                  = System.Drawing.Color.White;
            this.btnB.Location                   = new System.Drawing.Point(30, 198);
            this.btnB.Name                       = "btnB";
            this.btnB.Size                       = new System.Drawing.Size(840, 50);
            this.btnB.TabIndex                   = 3;
            this.btnB.Text                       = "  B)  ...";
            this.btnB.TextAlign                  = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB.UseVisualStyleBackColor    = false;
            this.btnB.Click                     += new System.EventHandler(this.btnB_Click);

            // btnC
            this.btnC.BackColor                  = System.Drawing.Color.FromArgb(40, 40, 60);
            this.btnC.Cursor                     = System.Windows.Forms.Cursors.Hand;
            this.btnC.FlatStyle                  = System.Windows.Forms.FlatStyle.Flat;
            this.btnC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 80, 120);
            this.btnC.FlatAppearance.BorderSize  = 1;
            this.btnC.Font                       = new System.Drawing.Font("Consolas", 11F);
            this.btnC.ForeColor                  = System.Drawing.Color.White;
            this.btnC.Location                   = new System.Drawing.Point(30, 256);
            this.btnC.Name                       = "btnC";
            this.btnC.Size                       = new System.Drawing.Size(840, 50);
            this.btnC.TabIndex                   = 4;
            this.btnC.Text                       = "  C)  ...";
            this.btnC.TextAlign                  = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnC.UseVisualStyleBackColor    = false;
            this.btnC.Click                     += new System.EventHandler(this.btnC_Click);

            // btnD
            this.btnD.BackColor                  = System.Drawing.Color.FromArgb(40, 40, 60);
            this.btnD.Cursor                     = System.Windows.Forms.Cursors.Hand;
            this.btnD.FlatStyle                  = System.Windows.Forms.FlatStyle.Flat;
            this.btnD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 80, 120);
            this.btnD.FlatAppearance.BorderSize  = 1;
            this.btnD.Font                       = new System.Drawing.Font("Consolas", 11F);
            this.btnD.ForeColor                  = System.Drawing.Color.White;
            this.btnD.Location                   = new System.Drawing.Point(30, 314);
            this.btnD.Name                       = "btnD";
            this.btnD.Size                       = new System.Drawing.Size(840, 50);
            this.btnD.TabIndex                   = 5;
            this.btnD.Text                       = "  D)  ...";
            this.btnD.TextAlign                  = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnD.UseVisualStyleBackColor    = false;
            this.btnD.Click                     += new System.EventHandler(this.btnD_Click);

            // lblFeedback
            this.lblFeedback.AutoSize  = false;
            this.lblFeedback.BackColor = System.Drawing.Color.Transparent;
            this.lblFeedback.Font      = new System.Drawing.Font("Consolas", 11F, System.Drawing.FontStyle.Bold);
            this.lblFeedback.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblFeedback.Location  = new System.Drawing.Point(30, 378);
            this.lblFeedback.Name      = "lblFeedback";
            this.lblFeedback.Size      = new System.Drawing.Size(840, 30);
            this.lblFeedback.TabIndex  = 6;
            this.lblFeedback.Text      = "";
            this.lblFeedback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFeedback.Visible   = false;

            // btnDalsi
            this.btnDalsi.BackColor                  = System.Drawing.Color.FromArgb(40, 80, 40);
            this.btnDalsi.Cursor                     = System.Windows.Forms.Cursors.Hand;
            this.btnDalsi.FlatStyle                  = System.Windows.Forms.FlatStyle.Flat;
            this.btnDalsi.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 160, 80);
            this.btnDalsi.FlatAppearance.BorderSize  = 2;
            this.btnDalsi.Font                       = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btnDalsi.ForeColor                  = System.Drawing.Color.White;
            this.btnDalsi.Location                   = new System.Drawing.Point(300, 428);
            this.btnDalsi.Name                       = "btnDalsi";
            this.btnDalsi.Size                       = new System.Drawing.Size(300, 50);
            this.btnDalsi.TabIndex                   = 7;
            this.btnDalsi.Text                       = "➡️  Další otázka";
            this.btnDalsi.UseVisualStyleBackColor    = false;
            this.btnDalsi.Visible                    = false;
            this.btnDalsi.Click                     += new System.EventHandler(this.btnDalsi_Click);

            // FormQuiz
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor           = System.Drawing.Color.FromArgb(20, 20, 35);
            this.ClientSize          = new System.Drawing.Size(900, 500);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.lblOtazka);
            this.Controls.Add(this.btnA);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.btnDalsi);
            this.FormBorderStyle  = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox      = false;
            this.Name             = "FormQuiz";
            this.StartPosition    = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text             = "🧠 IT Kvíz – Prokrastinační Zámek";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
