using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormQuiz : Form
    {
        private Button[] _answerButtons;

        public FormQuiz()
        {
            InitializeComponent();
            _answerButtons = new Button[] { btnA, btnB, btnC, btnD };
            NactiOtazku();
        }

        private void NactiOtazku()
        {
            var q = GameState.Questions[GameState.QuizIndex];

            lblProgress.Text = $"Otázka {GameState.QuizIndex + 1} / {GameState.Questions.Count}" +
                               $"   |   ✅ Správně: {GameState.CorrectAnswers}";
            lblOtazka.Text = q.Question;

            btnA.Text = $"  A)  {q.Options[0]}";
            btnB.Text = $"  B)  {q.Options[1]}";
            btnC.Text = $"  C)  {q.Options[2]}";
            btnD.Text = $"  D)  {q.Options[3]}";

            foreach (var btn in _answerButtons)
            {
                btn.Enabled   = true;
                btn.BackColor = Color.FromArgb(40, 40, 60);
            }

            lblFeedback.Visible = false;
            btnDalsi.Visible    = false;
        }

        private void Odpovez(int zvolenyIndex)
        {
            int spravnyIndex = GameState.Questions[GameState.QuizIndex].CorrectIdx;
            bool spravne     = zvolenyIndex == spravnyIndex;

            if (spravne) GameState.CorrectAnswers++;

            foreach (var btn in _answerButtons)
                btn.Enabled = false;

            _answerButtons[zvolenyIndex].BackColor = spravne
                ? Color.FromArgb(0, 100, 0)
                : Color.FromArgb(120, 0, 0);

            if (!spravne)
                _answerButtons[spravnyIndex].BackColor = Color.FromArgb(0, 120, 0);

            lblFeedback.Text      = spravne
                ? "✅ Správně! Dobře sis dával/a pozor!"
                : "❌ Špatně! Ale aspoň ses něco naučil/a.";
            lblFeedback.ForeColor = spravne ? Color.LimeGreen : Color.OrangeRed;
            lblFeedback.Visible   = true;

            bool posledni    = GameState.QuizIndex + 1 >= GameState.Questions.Count;
            btnDalsi.Text    = posledni ? "📊  Zobrazit výsledek" : "➡️  Další otázka";
            btnDalsi.Visible = true;
        }

        private void btnA_Click(object sender, EventArgs e) => Odpovez(0);
        private void btnB_Click(object sender, EventArgs e) => Odpovez(1);
        private void btnC_Click(object sender, EventArgs e) => Odpovez(2);
        private void btnD_Click(object sender, EventArgs e) => Odpovez(3);

        private void btnDalsi_Click(object sender, EventArgs e)
        {
            GameState.QuizIndex++;
            if (GameState.QuizIndex >= GameState.Questions.Count)
                GameState.Navigate(this, new FormQuizResult());
            else
                NactiOtazku();
        }
    }
}
