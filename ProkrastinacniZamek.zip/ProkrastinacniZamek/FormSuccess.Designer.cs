namespace ProkrastinacniZamek
{
    partial class FormSuccess
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblIcon;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.RichTextBox rtbSummary;
        private System.Windows.Forms.Button btnZnovu;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblIcon = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.rtbSummary = new System.Windows.Forms.RichTextBox();
            this.btnZnovu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblIcon
            // 
            this.lblIcon.BackColor = System.Drawing.Color.Transparent;
            this.lblIcon.Font = new System.Drawing.Font("Segoe UI Emoji", 52F);
            this.lblIcon.ForeColor = System.Drawing.Color.White;
            this.lblIcon.Location = new System.Drawing.Point(446, -8);
            this.lblIcon.Name = "lblIcon";
            this.lblIcon.Size = new System.Drawing.Size(140, 120);
            this.lblIcon.TabIndex = 0;
            this.lblIcon.Text = "🎉";
            this.lblIcon.Click += new System.EventHandler(this.lblIcon_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Consolas", 26F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblTitle.Location = new System.Drawing.Point(23, 112);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(983, 53);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "SOUBORY OBNOVENY!";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSubtitle
            // 
            this.lblSubtitle.BackColor = System.Drawing.Color.Transparent;
            this.lblSubtitle.Font = new System.Drawing.Font("Consolas", 11F);
            this.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(220)))), ((int)(((byte)(100)))));
            this.lblSubtitle.Location = new System.Drawing.Point(23, 169);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Size = new System.Drawing.Size(983, 30);
            this.lblSubtitle.TabIndex = 2;
            this.lblSubtitle.Text = "Prokrastinační Zámek poražen | Vzdělávací projekt";
            this.lblSubtitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rtbSummary
            // 
            this.rtbSummary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(30)))), ((int)(((byte)(0)))));
            this.rtbSummary.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbSummary.Font = new System.Drawing.Font("Consolas", 11F);
            this.rtbSummary.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(100)))));
            this.rtbSummary.Location = new System.Drawing.Point(46, 213);
            this.rtbSummary.Name = "rtbSummary";
            this.rtbSummary.ReadOnly = true;
            this.rtbSummary.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtbSummary.Size = new System.Drawing.Size(937, 489);
            this.rtbSummary.TabIndex = 3;
            this.rtbSummary.Text = "";
            // 
            // btnZnovu
            // 
            this.btnZnovu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(0)))));
            this.btnZnovu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZnovu.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnZnovu.FlatAppearance.BorderSize = 2;
            this.btnZnovu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZnovu.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold);
            this.btnZnovu.ForeColor = System.Drawing.Color.White;
            this.btnZnovu.Location = new System.Drawing.Point(337, 720);
            this.btnZnovu.Name = "btnZnovu";
            this.btnZnovu.Size = new System.Drawing.Size(343, 53);
            this.btnZnovu.TabIndex = 4;
            this.btnZnovu.Text = "🔄  Spustit znovu (demo)";
            this.btnZnovu.UseVisualStyleBackColor = false;
            this.btnZnovu.Click += new System.EventHandler(this.btnZnovu_Click);
            // 
            // FormSuccess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1029, 795);
            this.Controls.Add(this.lblIcon);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblSubtitle);
            this.Controls.Add(this.rtbSummary);
            this.Controls.Add(this.btnZnovu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormSuccess";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "🎉 Hotovo! – Prokrastinační Zámek";
            this.ResumeLayout(false);

        }
    }
}
