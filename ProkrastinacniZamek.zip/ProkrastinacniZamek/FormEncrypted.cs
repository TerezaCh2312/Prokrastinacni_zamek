using System;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormEncrypted : Form
    {
        private System.Windows.Forms.Timer _countdownTimer;
        private DateTime _deadline;

        public FormEncrypted()
        {
            InitializeComponent();

            int lockedCount = System.IO.Directory.GetFiles(GameState.ObetSlozka, "*" + GameState.LOCKED_EXT).Length;

            rtbNote.Text =
                "████████████████████████████████████████████\r\n" +
                "                                              \r\n" +
                "      AHA! Chytila jsem tě, prokrastinátore!       \r\n" +
                "                                                \r\n" +
                "████████████████████████████████████████████\r\n\r\n" +
                $"   Zašifrovala jsem {lockedCount} tvých souborů pomocí AES-256.\r\n" +
                "   Pokud chceš soubory zpátky, musíš:\r\n\r\n" +
                "   [A] Odpovědět správně na 5 otázek z IT bezpečnosti\r\n" +
                "   [B] Porazit mě v piškvorky 3×3\r\n" +
                "       (jsem jen počítač, zvládneš to... možná)\r\n\r\n" +
                "   Pokud nesplníš výzvu do hodiny...\r\n" +
                "   ...zapnu opravdu otravnou hudbu. Varuju tě.\r\n\r\n";
                            

            _deadline = DateTime.Now.AddHours(0.1);
            _countdownTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            _countdownTimer.Tick += OnCountdownTick;
            _countdownTimer.Start();
        }

        private void OnCountdownTick(object sender, EventArgs e)
        {
            var remaining = _deadline - DateTime.Now;
            if (remaining <= TimeSpan.Zero)
            {
                lblTimer.Text      = "⏰ ČAS VYPRŠEL! 🎵🎵🎵";
                lblTimer.ForeColor = System.Drawing.Color.White;
                GameState.StartAnnoyingMusic();
            }
            else
            {
                lblTimer.Text = $"⏱️ Zbývá: {remaining:hh\\:mm\\:ss}  –  pak zapnu hudbu...";
                if (remaining.TotalMinutes < 5)
                    lblTimer.ForeColor = System.Drawing.Color.FromArgb(255, 80, 80);
            }
        }

        private void btnSplnit_Click(object sender, EventArgs e)
        {
            _countdownTimer.Stop();
            GameState.Navigate(this, new FormChallengeChoice());
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _countdownTimer?.Stop();
            base.OnFormClosed(e);
        }

        private void lblIcon_Click(object sender, EventArgs e)
        {

        }
    }
}
