using System;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormChallengeChoice : Form
    {
        public FormChallengeChoice()
        {
            InitializeComponent();
        }

        private void btnKviz_Click(object sender, EventArgs e)
        {
            GameState.QuizIndex      = 0;
            GameState.CorrectAnswers = 0;
            GameState.Navigate(this, new FormQuiz());
        }

        private void btnPiskvorky_Click(object sender, EventArgs e)
        {
            GameState.Navigate(this, new FormTicTacToe());
        }
    }
}
