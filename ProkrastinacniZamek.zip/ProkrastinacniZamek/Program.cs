using System;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
                        
            var ctx = new ApplicationContext();
            GameState.AppContext = ctx;

            var intro = new FormIntro();
            intro.Show();

            Application.Run(ctx);
        }
    }
}
