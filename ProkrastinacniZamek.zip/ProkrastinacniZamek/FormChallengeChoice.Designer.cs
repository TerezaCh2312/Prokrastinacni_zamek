namespace ProkrastinacniZamek
{
    partial class FormChallengeChoice
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblIcon;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblVyber;
        private System.Windows.Forms.Button btnKviz;
        private System.Windows.Forms.Button btnPiskvorky;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblIcon = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblVyber = new System.Windows.Forms.Label();
            this.btnKviz = new System.Windows.Forms.Button();
            this.btnPiskvorky = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblIcon
            // 
            this.lblIcon.BackColor = System.Drawing.Color.Transparent;
            this.lblIcon.Font = new System.Drawing.Font("Segoe UI Emoji", 52F);
            this.lblIcon.ForeColor = System.Drawing.Color.White;
            this.lblIcon.Location = new System.Drawing.Point(432, 9);
            this.lblIcon.Name = "lblIcon";
            this.lblIcon.Size = new System.Drawing.Size(143, 114);
            this.lblIcon.TabIndex = 0;
            this.lblIcon.Text = "⚔️";
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Consolas", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(100)))));
            this.lblTitle.Location = new System.Drawing.Point(23, 128);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(983, 49);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "VYBER SI SVOU VÝZVU";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVyber
            // 
            this.lblVyber.BackColor = System.Drawing.Color.Transparent;
            this.lblVyber.Font = new System.Drawing.Font("Consolas", 12F);
            this.lblVyber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.lblVyber.Location = new System.Drawing.Point(23, 183);
            this.lblVyber.Name = "lblVyber";
            this.lblVyber.Size = new System.Drawing.Size(983, 30);
            this.lblVyber.TabIndex = 2;
            this.lblVyber.Text = "Splň jednu z výzev a získej klíč k dešifrování";
            this.lblVyber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnKviz
            // 
            this.btnKviz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(70)))));
            this.btnKviz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKviz.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.btnKviz.FlatAppearance.BorderSize = 2;
            this.btnKviz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKviz.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.btnKviz.ForeColor = System.Drawing.Color.White;
            this.btnKviz.Location = new System.Drawing.Point(183, 256);
            this.btnKviz.Name = "btnKviz";
            this.btnKviz.Size = new System.Drawing.Size(640, 107);
            this.btnKviz.TabIndex = 3;
            this.btnKviz.Text = "🧠  IT KVÍZ\r\n5 otázek z kybernetické bezpečnosti";
            this.btnKviz.UseVisualStyleBackColor = false;
            this.btnKviz.Click += new System.EventHandler(this.btnKviz_Click);
            // 
            // btnPiskvorky
            // 
            this.btnPiskvorky.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnPiskvorky.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPiskvorky.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnPiskvorky.FlatAppearance.BorderSize = 2;
            this.btnPiskvorky.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPiskvorky.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.btnPiskvorky.ForeColor = System.Drawing.Color.White;
            this.btnPiskvorky.Location = new System.Drawing.Point(183, 395);
            this.btnPiskvorky.Name = "btnPiskvorky";
            this.btnPiskvorky.Size = new System.Drawing.Size(640, 107);
            this.btnPiskvorky.TabIndex = 4;
            this.btnPiskvorky.Text = "❌⭕  PIŠKVORKY\r\nPoraz počítač v klasické hře 3×3";
            this.btnPiskvorky.UseVisualStyleBackColor = false;
            this.btnPiskvorky.Click += new System.EventHandler(this.btnPiskvorky_Click);
            // 
            // FormChallengeChoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1029, 555);
            this.Controls.Add(this.lblIcon);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblVyber);
            this.Controls.Add(this.btnKviz);
            this.Controls.Add(this.btnPiskvorky);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormChallengeChoice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "⚔️ Vyber výzvu – Prokrastinační Zámek";
            this.ResumeLayout(false);

        }
    }
}
