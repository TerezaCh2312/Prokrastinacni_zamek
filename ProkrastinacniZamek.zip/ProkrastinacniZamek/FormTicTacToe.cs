using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormTicTacToe : Form
    {
        private char[,] _board = new char[3, 3];
        private Button[,] _grid;
        private bool _playerTurn = true;
        private bool _hracVyhral = false;

        public FormTicTacToe()
        {
            InitializeComponent();
            _grid = new Button[3, 3]
            {
                { btn00, btn01, btn02 },
                { btn10, btn11, btn12 },
                { btn20, btn21, btn22 }
            };
        }

        private void btn00_Click(object sender, EventArgs e) => HracTah(0, 0);
        private void btn01_Click(object sender, EventArgs e) => HracTah(0, 1);
        private void btn02_Click(object sender, EventArgs e) => HracTah(0, 2);
        private void btn10_Click(object sender, EventArgs e) => HracTah(1, 0);
        private void btn11_Click(object sender, EventArgs e) => HracTah(1, 1);
        private void btn12_Click(object sender, EventArgs e) => HracTah(1, 2);
        private void btn20_Click(object sender, EventArgs e) => HracTah(2, 0);
        private void btn21_Click(object sender, EventArgs e) => HracTah(2, 1);
        private void btn22_Click(object sender, EventArgs e) => HracTah(2, 2);

        private void HracTah(int r, int c)
        {
            if (!_playerTurn || _board[r, c] != '\0') return;

            _board[r, c]          = 'X';
            _grid[r, c].Text      = "❌";
            _grid[r, c].ForeColor = Color.FromArgb(255, 80, 80);
            lblStatus.Text        = "Počítač přemýšlí...";

            if (ZkontrolujVyhru('X')) { ZobrazVysledek(true);  return; }
            if (JePlnoDeska())        { ZobrazVysledek(null);   return; }

            _playerTurn = false;
            Task.Delay(400).ContinueWith(t => this.Invoke((Action)PocitacTah));
        }

        private void PocitacTah()
        {
            var (r, c)            = NejlepsiTah();
            _board[r, c]          = 'O';
            _grid[r, c].Text      = "⭕";
            _grid[r, c].ForeColor = Color.FromArgb(100, 200, 255);

            if (ZkontrolujVyhru('O')) { ZobrazVysledek(false); return; }
            if (JePlnoDeska())        { ZobrazVysledek(null);  return; }

            _playerTurn    = true;
            lblStatus.Text = "Tvůj tah...";
        }

        private void ZobrazVysledek(bool? hracVyhral)
        {
            foreach (var btn in _grid)
                btn.Enabled = false;

            bool uspech;
            string zprava;
            if (hracVyhral == true)       { zprava = "🏆 Vyhrál/a jsi! Klíč je tvůj!";    uspech = true;  }
            else if (hracVyhral == false) { zprava = "🤖 Počítač vyhrál. Zkus to znovu!"; uspech = false; }
            else                          { zprava = "🤝 Remíza! Zkus to znovu.";          uspech = false; }

            _hracVyhral           = uspech;
            lblVysledek.Text      = zprava;
            lblVysledek.ForeColor = uspech ? Color.LimeGreen : Color.OrangeRed;
            lblVysledek.Visible   = true;

            if (uspech)
            {
                btnAkce.Text                       = "🔓  DEŠIFROVAT SOUBORY";
                btnAkce.BackColor                  = Color.FromArgb(0, 120, 0);
                btnAkce.FlatAppearance.BorderColor = Color.FromArgb(0, 200, 0);
            }
            else
            {
                btnAkce.Text                       = "🔄  Zkusit znovu";
                btnAkce.BackColor                  = Color.FromArgb(100, 60, 0);
                btnAkce.FlatAppearance.BorderColor = Color.FromArgb(200, 120, 0);
            }
            btnAkce.Visible = true;
        }

        private void btnAkce_Click(object sender, EventArgs e)
        {
            if (_hracVyhral)
            {
                GameState.StopAnnoyingMusic();
                GameState.RestoreFromBackup();
                GameState.Navigate(this, new FormSuccess());
            }
            else
            {
                GameState.Navigate(this, new FormChallengeChoice());
            }
        }

        private (int, int) NejlepsiTah()
        {
            int bestScore = int.MinValue;
            (int, int) best = (0, 0);
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 3; c++)
                    if (_board[r, c] == '\0')
                    {
                        _board[r, c] = 'O';
                        int score    = Minimax(false, 0);
                        _board[r, c] = '\0';
                        if (score > bestScore) { bestScore = score; best = (r, c); }
                    }
            return best;
        }

        private int Minimax(bool maximalizuje, int hloubka)
        {
            if (ZkontrolujVyhru('O')) return 10 - hloubka;
            if (ZkontrolujVyhru('X')) return hloubka - 10;
            if (JePlnoDeska())        return 0;

            int best = maximalizuje ? int.MinValue : int.MaxValue;
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 3; c++)
                    if (_board[r, c] == '\0')
                    {
                        _board[r, c] = maximalizuje ? 'O' : 'X';
                        int score    = Minimax(!maximalizuje, hloubka + 1);
                        _board[r, c] = '\0';
                        best = maximalizuje ? Math.Max(best, score) : Math.Min(best, score);
                    }
            return best;
        }

        private bool ZkontrolujVyhru(char h)
        {
            for (int i = 0; i < 3; i++)
            {
                if (_board[i, 0] == h && _board[i, 1] == h && _board[i, 2] == h) return true;
                if (_board[0, i] == h && _board[1, i] == h && _board[2, i] == h) return true;
            }
            if (_board[0, 0] == h && _board[1, 1] == h && _board[2, 2] == h) return true;
            if (_board[0, 2] == h && _board[1, 1] == h && _board[2, 0] == h) return true;
            return false;
        }

        private bool JePlnoDeska()
        {
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 3; c++)
                    if (_board[r, c] == '\0') return false;
            return true;
        }
    }
}
