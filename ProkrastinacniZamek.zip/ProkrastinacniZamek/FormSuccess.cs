using System;
using System.IO;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormSuccess : Form
    {
        public FormSuccess()
        {
            InitializeComponent();

            int obnoveno = Directory.GetFiles(GameState.ObetSlozka).Length;

            rtbSummary.Text =
                "✅ Gratuluji, zachránil/a jsi své soubory před prokrastinací!\r\n" +
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n\r\n" +
                $"   Obnoveno souborů:  {obnoveno} ks\r\n" +
                $"   Metoda obnovy:     SystemBackup (stínová kopie)\r\n" +
                $"   Šifra:             AES-256\r\n\r\n" +
                "📚 Důležité info:\r\n\r\n" +
                "   • Ransomware šifruje soubory a žádá výkupné\r\n" +
                "   • AES-256 je průmyslový standard šifrování\r\n" +
                "   • Zálohy (backup) jsou nejlepší ochrana před ransomware\r\n" +
                "   • Reálný ransomware funguje stejně – ale není to sranda\r\n\r\n" +
                "      Záloha byla vždy bezpečná v SystemBackup\\ –\r\n" +
                "      data nebyla nikdy skutečně ohrožena.\r\n\r\n";
               
        }

        private void btnZnovu_Click(object sender, EventArgs e)
        {
            GameState.Navigate(this, new FormIntro());
        }

        private void lblIcon_Click(object sender, EventArgs e)
        {

        }
    }
}
