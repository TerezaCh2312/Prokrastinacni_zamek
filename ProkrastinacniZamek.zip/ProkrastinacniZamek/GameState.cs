using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Threading;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    internal static class GameState
    {        
        public static ApplicationContext AppContext;

        public static readonly string AppDir       = AppDomain.CurrentDomain.BaseDirectory;
        public static readonly string ObetSlozka   = Path.Combine(AppDir, "ObetSlozka");
        public static readonly string BackupSlozka = Path.Combine(AppDir, "SystemBackup");
        public const string LOCKED_EXT = ".LOCKED";

        public static byte[] AesKey;
        public static byte[] AesIV;

        //kvíz
        public static int QuizIndex      = 0;
        public static int CorrectAnswers = 0;

        public static readonly List<(string Question, string[] Options, int CorrectIdx)> Questions =
            new List<(string, string[], int)>
            {
                ("Co je to AES-256?",
                 new[]{ "Antivirový software", "Symetrická šifra s 256bitovým klíčem",
                        "Typ síťového protokolu", "Databázový systém" }, 1),

                ("Co označuje zkratka 'CIA' v kybernetické bezpečnosti?",
                 new[]{ "Central Intelligence Agency", "Confidentiality, Integrity, Availability",
                        "Cyber Intrusion Alert", "Common Internet Architecture" }, 1),

                ("Co je to 'phishing'?",
                 new[]{ "Rybolov na internetu", "Typ šifrování dat",
                        "Podvodný útok pomocí falešných zpráv", "Firewall technika" }, 2),

                ("Jaký port standardně používá HTTPS?",
                 new[]{ "80", "21", "443", "8080" }, 2),

                ("Co je to 'SQL injection'?",
                 new[]{ "Způsob zálohy databáze", "Útok vkládáním škodlivého SQL kódu",
                        "Typ databázového indexu", "Metoda komprese dat" }, 1),
            };

        
        public static void EnsureFolders()
        {
            Directory.CreateDirectory(ObetSlozka);
            Directory.CreateDirectory(BackupSlozka);
        }

        public static void BackupFiles()
        {
            foreach (var file in Directory.GetFiles(ObetSlozka))
            {
                if (!file.EndsWith(LOCKED_EXT))
                {
                    string dest = Path.Combine(BackupSlozka, Path.GetFileName(file));
                    if (!File.Exists(dest))
                        File.Copy(file, dest);
                }
            }
        }

        public static void EncryptFile(string path)
        {
            byte[] plain = File.ReadAllBytes(path);
            byte[] encrypted;
            using (var aes = Aes.Create())
            {
                aes.Key = AesKey;
                aes.IV  = AesIV;
                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                        cs.Write(plain, 0, plain.Length);
                    encrypted = ms.ToArray();
                }
            }
            File.WriteAllBytes(path + LOCKED_EXT, encrypted);
            File.Delete(path);
        }

        public static void RestoreFromBackup()
        {
            foreach (var locked in Directory.GetFiles(ObetSlozka, "*" + LOCKED_EXT))
                File.Delete(locked);
            foreach (var backup in Directory.GetFiles(BackupSlozka))
            {
                string dest = Path.Combine(ObetSlozka, Path.GetFileName(backup));
                File.Copy(backup, dest, overwrite: true);
            }
        }

        public static void GenerateAesKey()
        {
            using (var aes = Aes.Create())
            {
                aes.KeySize = 256;
                aes.GenerateKey();
                aes.GenerateIV();
                AesKey = aes.Key;
                AesIV  = aes.IV;
            }
        }

        //otravná hudba
        private static System.Windows.Forms.Timer _musicTimer;
        private static int  _beepIndex = 0;
        private static bool _playing   = false;
        private static readonly int[] Melody = { 800, 600, 800, 600, 1000, 600, 800, 400, 800, 600 };

        public static void StartAnnoyingMusic()
        {
            if (_playing) return;
            _playing = true;
            _musicTimer = new System.Windows.Forms.Timer { Interval = 300 };
            _musicTimer.Tick += (s, e) =>
            {
                Console.Beep(Melody[_beepIndex % Melody.Length], 250);
                _beepIndex++;
            };
            _musicTimer.Start();
        }

        public static void StopAnnoyingMusic()
        {
            _musicTimer?.Stop();
            _playing = false;
        }
       
        public static void Navigate(Form current, Form next)
        {
            next.Show();
            current.Close();
        }

        public static void ExitApp()
        {
            AppContext?.ExitThread();
        }
    }
}
