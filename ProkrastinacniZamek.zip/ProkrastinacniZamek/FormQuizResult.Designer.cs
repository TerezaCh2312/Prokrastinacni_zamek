namespace ProkrastinacniZamek
{
    partial class FormQuizResult
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblIcon;
        private System.Windows.Forms.Label lblVysledek;
        private System.Windows.Forms.Label lblDetail;
        private System.Windows.Forms.Button btnAkce;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblIcon = new System.Windows.Forms.Label();
            this.lblVysledek = new System.Windows.Forms.Label();
            this.lblDetail = new System.Windows.Forms.Label();
            this.btnAkce = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblIcon
            // 
            this.lblIcon.BackColor = System.Drawing.Color.Transparent;
            this.lblIcon.Font = new System.Drawing.Font("Segoe UI Emoji", 52F);
            this.lblIcon.ForeColor = System.Drawing.Color.White;
            this.lblIcon.Location = new System.Drawing.Point(429, 9);
            this.lblIcon.Name = "lblIcon";
            this.lblIcon.Size = new System.Drawing.Size(138, 112);
            this.lblIcon.TabIndex = 0;
            this.lblIcon.Text = "🏆";
            // 
            // lblVysledek
            // 
            this.lblVysledek.BackColor = System.Drawing.Color.Transparent;
            this.lblVysledek.Font = new System.Drawing.Font("Consolas", 22F, System.Drawing.FontStyle.Bold);
            this.lblVysledek.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblVysledek.Location = new System.Drawing.Point(23, 139);
            this.lblVysledek.Name = "lblVysledek";
            this.lblVysledek.Size = new System.Drawing.Size(983, 53);
            this.lblVysledek.TabIndex = 1;
            this.lblVysledek.Text = "VÝBORNĚ!";
            this.lblVysledek.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDetail
            // 
            this.lblDetail.BackColor = System.Drawing.Color.Transparent;
            this.lblDetail.Font = new System.Drawing.Font("Consolas", 14F);
            this.lblDetail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblDetail.Location = new System.Drawing.Point(23, 205);
            this.lblDetail.Name = "lblDetail";
            this.lblDetail.Size = new System.Drawing.Size(983, 64);
            this.lblDetail.TabIndex = 2;
            this.lblDetail.Text = "5/5 správně – Klíč ti bude vydán!";
            this.lblDetail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAkce
            // 
            this.btnAkce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(0)))));
            this.btnAkce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAkce.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnAkce.FlatAppearance.BorderSize = 2;
            this.btnAkce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAkce.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btnAkce.ForeColor = System.Drawing.Color.White;
            this.btnAkce.Location = new System.Drawing.Point(331, 309);
            this.btnAkce.Name = "btnAkce";
            this.btnAkce.Size = new System.Drawing.Size(366, 58);
            this.btnAkce.TabIndex = 3;
            this.btnAkce.Text = "🔓  DEŠIFROVAT SOUBORY";
            this.btnAkce.UseVisualStyleBackColor = false;
            this.btnAkce.Click += new System.EventHandler(this.btnAkce_Click);
            // 
            // FormQuizResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(20)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(1029, 416);
            this.Controls.Add(this.lblIcon);
            this.Controls.Add(this.lblVysledek);
            this.Controls.Add(this.lblDetail);
            this.Controls.Add(this.btnAkce);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormQuizResult";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "📊 Výsledek kvízu";
            this.ResumeLayout(false);

        }
    }
}
