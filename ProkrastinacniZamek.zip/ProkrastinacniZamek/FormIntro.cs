using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormIntro : Form
    {
        public FormIntro()
        {
            InitializeComponent();
            GameState.EnsureFolders();

            rtbInfo.Text =
                "⚠️  UPOZORNĚNÍ – VZDĚLÁVACÍ NÁSTROJ\r\n" +
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n\r\n" +
                "Tato aplikace je ŠKOLNÍ PROJEKT demonstrující princip ransomware.\r\n" +
                "Není to virus. Neohrozí váš počítač.\r\n\r\n" +
                "📁  Co se stane po kliknutí na 'SPUSTIT ZÁMEK':\r\n" +
                "   • Šifruje POUZE soubory ve složce 'ObetSlozka' vedle .exe\r\n" +
                "   • Záloha je vždy v bezpečí ve složce 'SystemBackup'\r\n" +
                "   • Dešifrování = vyhrát piškvorky nebo odpovědět na kvíz\r\n\r\n" +
                "🔐  Technologie: AES-256 symetrická šifra\r\n" +
                "👩‍💻  Autor: Tereza Chachulová\r\n\r\n";
               
        }

        private void btnSpustit_Click(object sender, EventArgs e)
        {
            btnSpustit.Enabled = false;
            btnSpustit.Text    = "⏳ Šifruji...";

            string[] files = Directory.GetFiles(GameState.ObetSlozka);
            if (files.Length == 0)
            {
                MessageBox.Show("Ve složce ObetSlozka nejsou žádné soubory!\nPřidej tam nějaké .txt soubory.",
                    "Prázdná složka", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btnSpustit.Enabled = true;
                btnSpustit.Text    = "🔒  SPUSTIT ZÁMEK";
                return;
            }

            GameState.BackupFiles();
            GameState.GenerateAesKey();

            Task.Run(() =>
            {
                foreach (var file in files)
                    if (!file.EndsWith(GameState.LOCKED_EXT))
                    {
                        GameState.EncryptFile(file);
                        Thread.Sleep(200);
                    }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    MessageBox.Show("Chyba při šifrování: " + t.Exception.InnerException?.Message);
                    return;
                }
                this.Invoke((Action)(() => GameState.Navigate(this, new FormEncrypted())));
            });
        }
    }
}
