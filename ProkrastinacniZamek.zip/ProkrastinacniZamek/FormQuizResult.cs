using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProkrastinacniZamek
{
    public partial class FormQuizResult : Form
    {
        private bool _uspech;

        public FormQuizResult()
        {
            InitializeComponent();

            _uspech = GameState.CorrectAnswers >= 4;

            if (_uspech)
            {
                lblIcon.Text                       = "🏆";
                lblVysledek.Text                   = "VÝBORNĚ!";
                lblVysledek.ForeColor              = Color.LimeGreen;
                lblDetail.Text                     = $"{GameState.CorrectAnswers}/5 správně – Klíč ti bude vydán!";
                btnAkce.Text                       = "🔓  DEŠIFROVAT SOUBORY";
                btnAkce.BackColor                  = Color.FromArgb(0, 120, 0);
                btnAkce.FlatAppearance.BorderColor = Color.FromArgb(0, 200, 0);
            }
            else
            {
                lblIcon.Text                       = "😬";
                lblVysledek.Text                   = "NESTAČILO TO...";
                lblVysledek.ForeColor              = Color.OrangeRed;
                lblDetail.Text                     = $"{GameState.CorrectAnswers}/5 správně – potřebuješ alespoň 4.";
                btnAkce.Text                       = "🔄  Zkusit znovu";
                btnAkce.BackColor                  = Color.FromArgb(100, 60, 0);
                btnAkce.FlatAppearance.BorderColor = Color.FromArgb(200, 120, 0);
            }
        }

        private void btnAkce_Click(object sender, EventArgs e)
        {
            if (_uspech)
            {
                GameState.StopAnnoyingMusic();
                GameState.RestoreFromBackup();
                GameState.Navigate(this, new FormSuccess());
            }
            else
            {
                GameState.QuizIndex      = 0;
                GameState.CorrectAnswers = 0;
                GameState.Navigate(this, new FormChallengeChoice());
            }
        }
    }
}
