namespace ProkrastinacniZamek
{
    partial class FormTicTacToe
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblStatus;       
        private System.Windows.Forms.Button btn00;
        private System.Windows.Forms.Button btn01;
        private System.Windows.Forms.Button btn02;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Label lblVysledek;
        private System.Windows.Forms.Button btnAkce;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btn00 = new System.Windows.Forms.Button();
            this.btn01 = new System.Windows.Forms.Button();
            this.btn02 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.lblVysledek = new System.Windows.Forms.Label();
            this.btnAkce = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInfo
            // 
            this.lblInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblInfo.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.lblInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(100)))));
            this.lblInfo.Location = new System.Drawing.Point(23, 21);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(958, 36);
            this.lblInfo.TabIndex = 0;
            this.lblInfo.Text = "TY = ❌   POČÍTAČ = ⭕   Začínáš ty!";
            this.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Font = new System.Drawing.Font("Consolas", 11F);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.lblStatus.Location = new System.Drawing.Point(23, 62);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(958, 28);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.Text = "Tvůj tah...";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn00
            // 
            this.btn00.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn00.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn00.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn00.FlatAppearance.BorderSize = 2;
            this.btn00.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn00.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn00.ForeColor = System.Drawing.Color.White;
            this.btn00.Location = new System.Drawing.Point(280, 107);
            this.btn00.Name = "btn00";
            this.btn00.Size = new System.Drawing.Size(126, 117);
            this.btn00.TabIndex = 2;
            this.btn00.UseVisualStyleBackColor = false;
            this.btn00.Click += new System.EventHandler(this.btn00_Click);
            // 
            // btn01
            // 
            this.btn01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn01.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn01.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn01.FlatAppearance.BorderSize = 2;
            this.btn01.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn01.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn01.ForeColor = System.Drawing.Color.White;
            this.btn01.Location = new System.Drawing.Point(415, 107);
            this.btn01.Name = "btn01";
            this.btn01.Size = new System.Drawing.Size(126, 117);
            this.btn01.TabIndex = 3;
            this.btn01.UseVisualStyleBackColor = false;
            this.btn01.Click += new System.EventHandler(this.btn01_Click);
            // 
            // btn02
            // 
            this.btn02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn02.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn02.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn02.FlatAppearance.BorderSize = 2;
            this.btn02.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn02.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn02.ForeColor = System.Drawing.Color.White;
            this.btn02.Location = new System.Drawing.Point(550, 107);
            this.btn02.Name = "btn02";
            this.btn02.Size = new System.Drawing.Size(126, 117);
            this.btn02.TabIndex = 4;
            this.btn02.UseVisualStyleBackColor = false;
            this.btn02.Click += new System.EventHandler(this.btn02_Click);
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn10.FlatAppearance.BorderSize = 2;
            this.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn10.ForeColor = System.Drawing.Color.White;
            this.btn10.Location = new System.Drawing.Point(280, 233);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(126, 117);
            this.btn10.TabIndex = 5;
            this.btn10.UseVisualStyleBackColor = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn11.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn11.FlatAppearance.BorderSize = 2;
            this.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn11.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn11.ForeColor = System.Drawing.Color.White;
            this.btn11.Location = new System.Drawing.Point(415, 233);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(126, 117);
            this.btn11.TabIndex = 6;
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn12.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn12.FlatAppearance.BorderSize = 2;
            this.btn12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn12.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn12.ForeColor = System.Drawing.Color.White;
            this.btn12.Location = new System.Drawing.Point(550, 233);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(126, 117);
            this.btn12.TabIndex = 7;
            this.btn12.UseVisualStyleBackColor = false;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // btn20
            // 
            this.btn20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn20.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn20.FlatAppearance.BorderSize = 2;
            this.btn20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn20.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn20.ForeColor = System.Drawing.Color.White;
            this.btn20.Location = new System.Drawing.Point(280, 358);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(126, 117);
            this.btn20.TabIndex = 8;
            this.btn20.UseVisualStyleBackColor = false;
            this.btn20.Click += new System.EventHandler(this.btn20_Click);
            // 
            // btn21
            // 
            this.btn21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn21.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn21.FlatAppearance.BorderSize = 2;
            this.btn21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn21.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn21.ForeColor = System.Drawing.Color.White;
            this.btn21.Location = new System.Drawing.Point(415, 358);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(126, 117);
            this.btn21.TabIndex = 9;
            this.btn21.UseVisualStyleBackColor = false;
            this.btn21.Click += new System.EventHandler(this.btn21_Click);
            // 
            // btn22
            // 
            this.btn22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn22.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn22.FlatAppearance.BorderSize = 2;
            this.btn22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn22.Font = new System.Drawing.Font("Segoe UI Emoji", 32F);
            this.btn22.ForeColor = System.Drawing.Color.White;
            this.btn22.Location = new System.Drawing.Point(550, 358);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(126, 117);
            this.btn22.TabIndex = 10;
            this.btn22.UseVisualStyleBackColor = false;
            this.btn22.Click += new System.EventHandler(this.btn22_Click);
            // 
            // lblVysledek
            // 
            this.lblVysledek.BackColor = System.Drawing.Color.Transparent;
            this.lblVysledek.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.lblVysledek.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblVysledek.Location = new System.Drawing.Point(23, 493);
            this.lblVysledek.Name = "lblVysledek";
            this.lblVysledek.Size = new System.Drawing.Size(983, 38);
            this.lblVysledek.TabIndex = 11;
            this.lblVysledek.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblVysledek.Visible = false;
            // 
            // btnAkce
            // 
            this.btnAkce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(0)))));
            this.btnAkce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAkce.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnAkce.FlatAppearance.BorderSize = 2;
            this.btnAkce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAkce.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btnAkce.ForeColor = System.Drawing.Color.White;
            this.btnAkce.Location = new System.Drawing.Point(299, 543);
            this.btnAkce.Name = "btnAkce";
            this.btnAkce.Size = new System.Drawing.Size(366, 53);
            this.btnAkce.TabIndex = 12;
            this.btnAkce.Text = "🔓  DEŠIFROVAT SOUBORY";
            this.btnAkce.UseVisualStyleBackColor = false;
            this.btnAkce.Visible = false;
            this.btnAkce.Click += new System.EventHandler(this.btnAkce_Click);
            // 
            // FormTicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.ClientSize = new System.Drawing.Size(973, 619);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btn00);
            this.Controls.Add(this.btn01);
            this.Controls.Add(this.btn02);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.btn20);
            this.Controls.Add(this.btn21);
            this.Controls.Add(this.btn22);
            this.Controls.Add(this.lblVysledek);
            this.Controls.Add(this.btnAkce);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormTicTacToe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "❌⭕ Piškvorky – Prokrastinační Zámek";
            this.ResumeLayout(false);

        }
    }
}
